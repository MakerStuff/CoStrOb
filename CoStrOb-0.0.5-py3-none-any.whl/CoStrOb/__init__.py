import time

def currentMillis():
	return(int(time.time() * 1000))
class CoStrOb:
	def __init__(self,interval = 1000):
		self.interval=interval
		self.last = currentMillis()
		self.error = 0
	def getPermission(self,precise = False):
		self.lag = (currentMillis() - (self.last + self.interval))
		if(self.lag>=0):
			self.last=currentMillis()
		if(precise):
			return(self.lag)
		elif(self.lag>=0):
			return(True)
		else:
			return(False)
	def setInterval(self,interval):
		self.interval = interval
		return(self.interval)
	def getInterval(self):
		return(self.interval)
	def getLag(self):
		return(self.lag)

if __name__=="__main__":
	# This example only runs if your are calling the file directly:
	print("Crtl+C to exit program")
	interval = input("Enter your interval in milliseconds: ")
	print("Printing 'Hello World' every " + str(interval) + " milliseconds in a function that returns 'True'/'False' or the number of milliseconds until the next returning of 'True'")
	time.sleep(5)
	printer = CoStrOb(interval)
	try:
		selection = 2 # Enter 0 ... 2 to select the example
		while(True):
			if(selection == 0):
				# Gives an answer as to if you are allowed by now to do what you want
				# and shows how much your code is lagging behind your schedule.
				permission = printer.getPermission()
				if(permission == True):
					print("Regular call:")
					print(permission)
					print("Lagging " + str(printer.getLag()) + " milliseconds behind.")
			elif(selection == 1):
				# Returns the exact time untill you get permission next time.
				permission = printer.getPermission(True)
				if(permission >= 0):
					print("Calling with precise set to 'True':")
					print("lacking behind " + str(permission) + " millisecond(s)")
			elif(selection == 2):
				print(printer.getPermission())
				print(printer.getPermission(True))
				print(printer.getLag())
	except KeyboardInterrupt:
		pass
