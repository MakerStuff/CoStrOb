Copyright (c) 2018 Fabian Becker

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


Example:

	import CoStrOb
	import time
	try:
		while(True):
			interval = int(input("Enter your interval in milliseconds: "))
			print("Printing 'Hello World' every " + str(interval) + " milliseconds in a function that returns 'True'/'False' or the number of milliseconds until the next returning of 'True'")
			printer = CoStrOb.CoStrOb(interval)
			selection = int(input("Select your example (0, 1 or 2): ")) # Enter 0 ... 2 to select the example
			try:
					while(True):
					if(selection == 0):
						# Gives an answer as to if you are allowed by now to do what you want
						# and shows how much your code is lagging behind your schedule.
						permission = printer.getPermission()
						if(permission == True):
							print("Regular call:")
							print(permission)
							print("Lagging " + str(printer.getLag()) + " milliseconds behind.")
					elif(selection == 1):
						# Returns the exact time untill you get permission next time.
						permission = printer.getPermission(True)
						if(permission >= 0):
							print("Calling with precise set to 'True':")
							print("lacking behind " + str(permission) + " millisecond(s)")
					elif(selection == 2):
						print(printer.getPermission())
						print(printer.getPermission(True))
						print(printer.getLag())
			except KeyboardInterrupt:
				pass
	except KeyboardInterrupt:
		pass
